# Azure SQL Hackathon Frontend Demo

A standalone presentation/demo frontend for the Azure SQL hackathon project.

## Demo login
- Email: `demo@azureportal.com`
- Password: `Demo@1234`

## Run
```bash
npm install
npm start
```
Open http://localhost:5000

This version intentionally uses mock frontend data so the UI can be demonstrated without Azure credentials. For live deployment, connect the UI to the Node.js + Azure SQL backend from the complete project.
